#ifndef MBFL_NLS_HY_H
#define MBFL_NLS_HY_H

#include "mbfilter.h"
#include "nls_hy.h"

extern const mbfl_language mbfl_language_armenian;

#endif /* MBFL_NLS_HY_H */
