<?php

/** @generate-function-entries */

function ctype_alnum($text): bool {}

function ctype_alpha($text): bool {}

function ctype_cntrl($text): bool {}

function ctype_digit($text): bool {}

function ctype_lower($text): bool {}

function ctype_graph($text): bool {}

function ctype_print($text): bool {}

function ctype_punct($text): bool {}

function ctype_space($text): bool {}

function ctype_upper($text): bool {}

function ctype_xdigit($text): bool {}
